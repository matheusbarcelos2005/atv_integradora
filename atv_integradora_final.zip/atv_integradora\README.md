# Atividade Integradora

Aplicacao web desenvolvida para a Atividade Integradora. O sistema permite digitar uma mensagem em uma pagina web, enviar essa mensagem para um servico externo e exibir a resposta retornada na tela.

## Objetivo

Demonstrar a integracao entre uma interface web, uma aplicacao Flask e um servico externo, mantendo separacao entre validacao, regra de negocio e comunicacao com o cliente HTTP.

## Funcionalidades

- Envio de mensagens pela interface web.
- Validacao de mensagens vazias ou muito longas.
- Exibicao da resposta retornada pelo servico.
- Tratamento de erros de validacao e falhas de comunicacao.
- Testes automatizados para envio, validacao e recebimento de respostas.

## Tecnologias usadas

- Python
- Flask
- HTML, CSS e JavaScript
- Pytest

## Estrutura do projeto

```text
atv_integradora/
|-- src/
|   |-- app.py
|   |-- chat_client.py
|   |-- external_client.py
|   |-- chat_service.py
|   `-- message_validator.py
|-- templates/
|   `-- index.html
|-- static/
|   |-- style.css
|   `-- app.js
|-- tests/
|   |-- test_send.py
|   `-- test_receive.py
|-- requirements.txt
|-- .env.example
`-- README.md
```

## Como executar

Instale as dependencias:

```powershell
pip install -r requirements.txt
```

Inicie o projeto:

```powershell
python -m src.app
```

Depois acesse no navegador:

```text
http://127.0.0.1:5000
```

## Como usar

1. Abra a pagina no navegador.
2. Digite uma pergunta no campo de texto.
3. Clique em "Enviar".
4. A resposta sera exibida na tela.

## Testes

Para rodar os testes:

```powershell
python -m pytest
```

Os testes verificam se o envio da mensagem e o recebimento da resposta estao funcionando corretamente.

## Organizacao do codigo

- `src/app.py`: cria a aplicacao Flask e define as rotas.
- `src/chat_service.py`: concentra a regra de negocio do envio da mensagem.
- `src/external_client.py`: faz a comunicacao com o servico externo.
- `src/message_validator.py`: valida o texto digitado pelo usuario.
- `templates/index.html`: estrutura da pagina.
- `static/app.js`: controla o envio da mensagem e a exibicao da resposta.
- `static/style.css`: define o visual da aplicacao.
